# APK oluşturma

Bu projede `.github/workflows/android-apk.yml` hazırdır.

GitHub'a yüklendiğinde Actions sekmesindeki **Build Android APK** akışı otomatik çalışır.
Build tamamlanınca `Mino-Kayip-Yildizlar-v0.2-APK` adlı artifact içinden APK indirilebilir.

Yerel/EAS alternatifi:

```bash
npm install
npx eas-cli@latest build -p android --profile preview
```
