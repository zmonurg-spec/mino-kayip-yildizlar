# Mino: Kayıp Yıldızların Peşinde — v0.2

7 yaş grubu için Android odaklı Expo / React Native çocuk macera oyunu.

## Oynanabilir içerik
- Ana menü ve Gizemli Orman haritası
- Bölüm 1: Hafıza Patikası — 12 kart / 6 eş
- Bölüm 2: Sayı Köprüsü — 7 yaş düzeyi toplama-çıkarma
- Bölüm 3: Parıltı Taşları — süreli kristal toplama
- Her oyunda 1–3 yıldız ve coin ödülü
- En iyi yıldız derecesini saklama
- AsyncStorage ile kalıcı ilerleme
- Ağaç Evi: coin ile 6 eşya satın alma
- Koleksiyon: başarılar ve alınan eşyalar
- Ayarlar ve ilerlemeyi sıfırlama
- Reklam veya uygulama içi satın alma yok

## Test
```bash
npm install
npx expo start
```

## APK
```bash
npx eas-cli@latest build -p android --profile preview
```
