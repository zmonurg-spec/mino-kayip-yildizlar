import React, { useEffect, useMemo, useState } from 'react';
import {
  Dimensions,
  ImageBackground,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width, height } = Dimensions.get('window');
const HOME = require('./assets/home.png');
const MAP = require('./assets/map.png');
const SAVE_KEY = 'mino-save-v2';

const INITIAL_SAVE = {
  stars: 27,
  coins: 640,
  best: { crystal: 0, memory: 0, math: 0 },
  unlocked: 3,
  owned: [],
  music: true,
  effects: true,
};

const SHOP_ITEMS = [
  { id: 'telescope', icon: '🔭', name: 'Teleskop', price: 80 },
  { id: 'lamp', icon: '🏮', name: 'Yıldız Feneri', price: 55 },
  { id: 'plant', icon: '🪴', name: 'Orman Bitkisi', price: 40 },
  { id: 'rug', icon: '🟩', name: 'Yumuşak Halı', price: 65 },
  { id: 'books', icon: '📚', name: 'Macera Kitapları', price: 70 },
  { id: 'plush', icon: '🧸', name: 'Pufi Oyuncağı', price: 90 },
];

function OverlayButton({ style, onPress, label, disabled }) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      accessibilityLabel={label}
      activeOpacity={0.75}
      disabled={disabled}
      onPress={onPress}
      style={[styles.hotspot, style]}
    />
  );
}

function TopResources({ stars, coins }) {
  return (
    <View style={styles.resourceOverlay} pointerEvents="none">
      <View style={styles.resourcePill}><Text style={styles.resourceText}>⭐ {stars}</Text></View>
      <View style={styles.resourcePill}><Text style={styles.resourceText}>🪙 {coins}</Text></View>
    </View>
  );
}

function HomeScreen({ save, onPlay, onMiniGames, onTree, onCollection, onSettings }) {
  return (
    <ImageBackground source={HOME} resizeMode="cover" style={styles.full}>
      <StatusBar hidden />
      <TopResources stars={save.stars} coins={save.coins} />
      <OverlayButton label="Oyna" onPress={onPlay} style={{ left: '24%', top: '53%', width: '52%', height: '9%' }} />
      <OverlayButton label="Ağaç Evim" onPress={onTree} style={{ left: '5%', top: '62%', width: '23%', height: '10%' }} />
      <OverlayButton label="Mini Oyunlar" onPress={onMiniGames} style={{ left: '29%', top: '62%', width: '23%', height: '10%' }} />
      <OverlayButton label="Koleksiyon" onPress={onCollection} style={{ left: '53%', top: '62%', width: '23%', height: '10%' }} />
      <OverlayButton label="Ayarlar" onPress={onSettings} style={{ left: '77%', top: '62%', width: '19%', height: '10%' }} />
    </ImageBackground>
  );
}

function MapScreen({ save, onBack, onStart }) {
  const [selected, setSelected] = useState(3);
  const games = {
    1: { title: 'Bölüm 1: Hafıza Patikası', sub: 'Ormandaki eş kartları bul.', key: 'memory' },
    2: { title: 'Bölüm 2: Sayı Köprüsü', sub: 'Doğru cevabı seç ve köprüyü geç.', key: 'math' },
    3: { title: 'Bölüm 3: Parıltı Taşları', sub: '6 kristali süre bitmeden topla.', key: 'crystal' },
  };
  const current = games[selected];
  return (
    <ImageBackground source={MAP} resizeMode="cover" style={styles.full}>
      <StatusBar hidden />
      <OverlayButton label="Geri" onPress={onBack} style={{ left: '1%', top: '1%', width: '20%', height: '7%' }} />
      <OverlayButton label="Bölüm 1" onPress={() => setSelected(1)} style={{ left: '6%', top: '62%', width: '18%', height: '9%' }} />
      <OverlayButton label="Bölüm 2" onPress={() => setSelected(2)} style={{ left: '23%', top: '61%', width: '19%', height: '9%' }} />
      <OverlayButton label="Bölüm 3" onPress={() => setSelected(3)} style={{ left: '40%', top: '58%', width: '23%', height: '11%' }} />
      <View style={styles.mapChoice} pointerEvents="box-none">
        <Text style={styles.mapChoiceTitle}>{current.title}</Text>
        <Text style={styles.mapChoiceSub}>{current.sub}</Text>
        <Text style={styles.mapBest}>En iyi: {'⭐'.repeat(save.best[current.key] || 0)}{'☆'.repeat(3 - (save.best[current.key] || 0))}</Text>
        <TouchableOpacity onPress={() => onStart(current.key)} style={styles.mapStartButton}>
          <Text style={styles.mapStartText}>Başla ›</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

function GameShell({ title, subtitle, save, onExit, children, footer }) {
  return (
    <View style={styles.gameRoot}>
      <StatusBar hidden />
      <SafeAreaView style={styles.full}>
        <View style={styles.hudRow}>
          <TouchableOpacity onPress={onExit} style={styles.roundButton}><Text style={styles.roundButtonText}>‹</Text></TouchableOpacity>
          <View style={styles.hudPill}><Text style={styles.hudText}>⭐ {save.stars}</Text></View>
          <View style={styles.hudPill}><Text style={styles.hudText}>🪙 {save.coins}</Text></View>
        </View>
        <View style={styles.missionBox}>
          <Text style={styles.missionTitle}>{title}</Text>
          <Text style={styles.missionText}>{subtitle}</Text>
        </View>
        <View style={styles.gameArea}>{children}</View>
        {footer}
      </SafeAreaView>
    </View>
  );
}

function ResultModal({ visible, title, rating, text, primaryLabel, onPrimary, onExit }) {
  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.modalShade}>
        <View style={styles.resultCard}>
          <Text style={styles.resultTitle}>{title}</Text>
          <Text style={styles.resultStars}>{'⭐'.repeat(rating)}{'☆'.repeat(3 - rating)}</Text>
          <Text style={styles.resultText}>{text}</Text>
          <TouchableOpacity onPress={onPrimary} style={styles.primaryButton}><Text style={styles.primaryButtonText}>{primaryLabel}</Text></TouchableOpacity>
          <TouchableOpacity onPress={onExit} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>Haritaya Dön</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const CRYSTAL_POSITIONS = [
  { x: 0.08, y: 0.10 }, { x: 0.56, y: 0.08 }, { x: 0.68, y: 0.24 }, { x: 0.12, y: 0.36 },
  { x: 0.58, y: 0.43 }, { x: 0.30, y: 0.57 }, { x: 0.69, y: 0.61 }, { x: 0.08, y: 0.64 },
];

function CrystalGame({ save, onExit, onComplete }) {
  const [timeLeft, setTimeLeft] = useState(30);
  const [collected, setCollected] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [positionIndex, setPositionIndex] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    if (finished) return;
    if (timeLeft <= 0) { setFinished(true); return; }
    const timer = setTimeout(() => setTimeLeft((v) => v - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft, finished]);
  useEffect(() => { if (collected >= 6 && !finished) setFinished(true); }, [collected, finished]);

  const rating = collected < 6 ? 0 : timeLeft >= 16 && mistakes === 0 ? 3 : timeLeft >= 7 ? 2 : 1;
  const reward = rating * 10;
  const pos = CRYSTAL_POSITIONS[positionIndex % CRYSTAL_POSITIONS.length];
  const reset = () => { setTimeLeft(30); setCollected(0); setMistakes(0); setPositionIndex(0); setFinished(false); };

  return (
    <GameShell title="Parıltı Taşları" subtitle="6 kristali süre bitmeden bul!" save={save} onExit={onExit}
      footer={<View style={styles.tipBoxStatic}><Text style={styles.tipText}>💎 Kristale dokun. 🍄 ve 🪨 tuzaklarına dikkat!</Text></View>}>
      <View style={styles.gameStats}><Text style={styles.statText}>💎 {collected}/6</Text><Text style={styles.statText}>⏱️ {timeLeft}</Text><Text style={styles.statText}>⚠️ {mistakes}</Text></View>
      {!finished && <>
        <Pressable onPress={() => { setCollected(v => v + 1); setPositionIndex(v => (v + 3) % CRYSTAL_POSITIONS.length); }}
          style={[styles.crystal, { left: (width - 32) * pos.x, top: 55 + (height * 0.42) * pos.y }]}>
          <Text style={styles.crystalEmoji}>💎</Text><Text style={styles.sparkle}>✨</Text>
        </Pressable>
        <Pressable onPress={() => setMistakes(v => v + 1)} style={[styles.decoy, { left: '18%', top: '48%' }]}><Text style={styles.decoyEmoji}>🍄</Text></Pressable>
        <Pressable onPress={() => setMistakes(v => v + 1)} style={[styles.decoy, { right: '12%', top: '35%' }]}><Text style={styles.decoyEmoji}>🪨</Text></Pressable>
      </>}
      <ResultModal visible={finished} title={collected >= 6 ? 'Harika!' : 'Süre Bitti'} rating={rating}
        text={collected >= 6 ? `6 kristali topladın! +${reward} coin.` : `${collected}/6 kristal buldun. Bir kez daha deneyelim!`}
        primaryLabel={collected >= 6 ? 'Ödülü Al' : 'Tekrar Dene'} onPrimary={collected >= 6 ? () => onComplete('crystal', rating, reward) : reset} onExit={onExit} />
    </GameShell>
  );
}

const MEMORY_SYMBOLS = ['⭐', '💎', '🍄', '🦋', '🌼', '🐿️'];
function shuffle(arr) { return [...arr].sort(() => Math.random() - 0.5); }

function MemoryGame({ save, onExit, onComplete }) {
  const newDeck = () => shuffle(MEMORY_SYMBOLS.flatMap((s, i) => [{ id: `${i}a`, s }, { id: `${i}b`, s }]));
  const [deck, setDeck] = useState(newDeck);
  const [open, setOpen] = useState([]);
  const [matched, setMatched] = useState([]);
  const [moves, setMoves] = useState(0);
  const [lock, setLock] = useState(false);

  const done = matched.length === 12;
  const rating = done ? moves <= 10 ? 3 : moves <= 14 ? 2 : 1 : 0;
  const reward = rating * 12;

  const tapCard = (card) => {
    if (lock || open.includes(card.id) || matched.includes(card.id) || done) return;
    const next = [...open, card.id];
    setOpen(next);
    if (next.length === 2) {
      setMoves(v => v + 1); setLock(true);
      const [a, b] = next.map(id => deck.find(c => c.id === id));
      if (a.s === b.s) {
        setTimeout(() => { setMatched(v => [...v, a.id, b.id]); setOpen([]); setLock(false); }, 450);
      } else {
        setTimeout(() => { setOpen([]); setLock(false); }, 800);
      }
    }
  };
  const reset = () => { setDeck(newDeck()); setOpen([]); setMatched([]); setMoves(0); setLock(false); };

  return (
    <GameShell title="Hafıza Patikası" subtitle="Aynı sembolleri eşleştir!" save={save} onExit={onExit}
      footer={<View style={styles.tipBoxStatic}><Text style={styles.tipText}>🧠 Hamle: {moves} · Eşleşme: {matched.length / 2}/6</Text></View>}>
      <View style={styles.memoryGrid}>
        {deck.map(card => {
          const shown = open.includes(card.id) || matched.includes(card.id);
          return <TouchableOpacity key={card.id} onPress={() => tapCard(card)} style={[styles.memoryCard, matched.includes(card.id) && styles.memoryMatched]}>
            <Text style={styles.memoryText}>{shown ? card.s : '❓'}</Text>
          </TouchableOpacity>;
        })}
      </View>
      <ResultModal visible={done} title="Tüm Eşleri Buldun!" rating={rating} text={`${moves} hamlede tamamladın. +${reward} coin.`}
        primaryLabel="Ödülü Al" onPrimary={() => onComplete('memory', rating, reward)} onExit={onExit} />
    </GameShell>
  );
}

const MATH_QUESTIONS = [
  { q: '3 + 4 = ?', a: 7, options: [6, 7, 8] },
  { q: '9 - 3 = ?', a: 6, options: [5, 6, 7] },
  { q: '5 + 2 = ?', a: 7, options: [7, 8, 9] },
  { q: '10 - 4 = ?', a: 6, options: [4, 6, 8] },
  { q: '2 + 6 = ?', a: 8, options: [7, 8, 9] },
  { q: '8 - 5 = ?', a: 3, options: [2, 3, 4] },
];

function MathGame({ save, onExit, onComplete }) {
  const [index, setIndex] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [mistakes, setMistakes] = useState(0);
  const [feedback, setFeedback] = useState('');
  const done = index >= MATH_QUESTIONS.length;
  const rating = done ? mistakes === 0 ? 3 : mistakes <= 2 ? 2 : 1 : 0;
  const reward = rating * 11;
  const answer = (value) => {
    if (feedback || done) return;
    const q = MATH_QUESTIONS[index];
    if (value === q.a) { setCorrect(v => v + 1); setFeedback('Doğru! ⭐'); }
    else { setMistakes(v => v + 1); setFeedback(`Bir daha düşün! Doğru cevap ${q.a}.`); }
    setTimeout(() => { setFeedback(''); setIndex(v => v + 1); }, 700);
  };
  const reset = () => { setIndex(0); setCorrect(0); setMistakes(0); setFeedback(''); };
  const q = MATH_QUESTIONS[Math.min(index, MATH_QUESTIONS.length - 1)];

  return (
    <GameShell title="Sayı Köprüsü" subtitle="Doğru cevapları seç, Mino köprüyü geçsin!" save={save} onExit={onExit}
      footer={<View style={styles.tipBoxStatic}><Text style={styles.tipText}>✅ {correct}/6 · ⚠️ {mistakes}</Text></View>}>
      {!done && <View style={styles.mathWrap}>
        <Text style={styles.mathProgress}>Soru {index + 1}/6</Text>
        <View style={styles.mathQuestion}><Text style={styles.mathQuestionText}>{q.q}</Text></View>
        <View style={styles.answerRow}>{q.options.map(v => <TouchableOpacity key={v} onPress={() => answer(v)} style={styles.answerButton}><Text style={styles.answerText}>{v}</Text></TouchableOpacity>)}</View>
        <Text style={styles.feedbackText}>{feedback}</Text>
      </View>}
      <ResultModal visible={done} title="Köprüyü Geçtin!" rating={rating} text={`${correct}/6 doğru cevap. +${reward} coin.`}
        primaryLabel="Ödülü Al" onPrimary={() => onComplete('math', rating, reward)} onExit={onExit} />
    </GameShell>
  );
}

function MiniGamesScreen({ save, onBack, onStart }) {
  const cards = [
    { key: 'crystal', icon: '💎', title: 'Parıltı Avı', sub: 'Kristalleri süre bitmeden topla.' },
    { key: 'memory', icon: '🧠', title: 'Hafıza Kartları', sub: 'Eşlerini bul, hafızanı güçlendir.' },
    { key: 'math', icon: '🔢', title: 'Sayı Köprüsü', sub: '7 yaşa uygun eğlenceli işlemler.' },
  ];
  return (
    <View style={styles.miniRoot}><StatusBar hidden /><SafeAreaView style={styles.full}>
      <View style={styles.miniHeader}><TouchableOpacity onPress={onBack} style={styles.roundButton}><Text style={styles.roundButtonText}>‹</Text></TouchableOpacity><Text style={styles.miniTitle}>Mini Oyunlar</Text><View style={{ width: 48 }} /></View>
      <Text style={styles.miniSubtitle}>Mino ile kısa maceralara katıl!</Text>
      {cards.map(card => <TouchableOpacity key={card.key} onPress={() => onStart(card.key)} style={styles.gameCard}>
        <Text style={styles.gameCardIcon}>{card.icon}</Text><View style={{ flex: 1 }}><Text style={styles.gameCardTitle}>{card.title}</Text><Text style={styles.gameCardSub}>{card.sub}</Text><Text style={styles.bestSmall}>En iyi: {'⭐'.repeat(save.best[card.key] || 0)}{'☆'.repeat(3 - (save.best[card.key] || 0))}</Text></View><Text style={styles.gameCardState}>Oyna ›</Text>
      </TouchableOpacity>)}
    </SafeAreaView></View>
  );
}

function TreeHouseScreen({ save, onBack, onBuy }) {
  return (
    <View style={styles.panelRoot}><StatusBar hidden /><SafeAreaView style={styles.full}>
      <PanelHeader title="Ağaç Evim" onBack={onBack} right={`🪙 ${save.coins}`} />
      <ScrollView contentContainerStyle={styles.scrollPad}>
        <View style={styles.treePreview}><Text style={styles.treeEmoji}>🌳🏠</Text><Text style={styles.treeTitle}>Mino'nun Ağaç Evi</Text><Text style={styles.treeSub}>{save.owned.length} / {SHOP_ITEMS.length} eşya yerleştirildi</Text><View style={styles.ownedRow}>{save.owned.map(id => <Text key={id} style={styles.ownedIcon}>{SHOP_ITEMS.find(x => x.id === id)?.icon}</Text>)}</View></View>
        <Text style={styles.sectionTitle}>Dükkan</Text>
        <View style={styles.shopGrid}>{SHOP_ITEMS.map(item => {
          const owned = save.owned.includes(item.id); const enough = save.coins >= item.price;
          return <View key={item.id} style={styles.shopCard}><Text style={styles.shopIcon}>{item.icon}</Text><Text style={styles.shopName}>{item.name}</Text><TouchableOpacity disabled={owned || !enough} onPress={() => onBuy(item)} style={[styles.buyButton, (owned || !enough) && styles.buyDisabled]}><Text style={styles.buyText}>{owned ? 'Alındı ✓' : `🪙 ${item.price}`}</Text></TouchableOpacity></View>;
        })}</View>
      </ScrollView>
    </SafeAreaView></View>
  );
}

function CollectionScreen({ save, onBack }) {
  return (
    <View style={styles.panelRoot}><StatusBar hidden /><SafeAreaView style={styles.full}>
      <PanelHeader title="Koleksiyon" onBack={onBack} right={`⭐ ${save.stars}`} />
      <ScrollView contentContainerStyle={styles.scrollPad}>
        <Text style={styles.collectionHero}>🏆</Text><Text style={styles.collectionTitle}>Macera Albümü</Text>
        {['memory','math','crystal'].map((key, i) => <View key={key} style={styles.badgeCard}><Text style={styles.badgeIcon}>{['🧠','🔢','💎'][i]}</Text><View style={{flex:1}}><Text style={styles.badgeName}>{['Hafıza Ustası','Sayı Gezgini','Kristal Avcısı'][i]}</Text><Text style={styles.badgeSub}>{save.best[key] > 0 ? `${save.best[key]} yıldızlık başarı` : 'Henüz kazanılmadı'}</Text></View><Text style={styles.badgeStars}>{'⭐'.repeat(save.best[key] || 0)}{'☆'.repeat(3-(save.best[key]||0))}</Text></View>)}
        <Text style={styles.sectionTitle}>Ağaç Evi Eşyaları</Text>
        <View style={styles.collectionGrid}>{SHOP_ITEMS.map(item => <View key={item.id} style={[styles.collectItem, !save.owned.includes(item.id) && styles.collectLocked]}><Text style={styles.collectIcon}>{save.owned.includes(item.id) ? item.icon : '🔒'}</Text><Text style={styles.collectName}>{item.name}</Text></View>)}</View>
      </ScrollView>
    </SafeAreaView></View>
  );
}

function PanelHeader({ title, onBack, right }) {
  return <View style={styles.panelHeader}><TouchableOpacity onPress={onBack} style={styles.roundButton}><Text style={styles.roundButtonText}>‹</Text></TouchableOpacity><Text style={styles.panelTitle}>{title}</Text><Text style={styles.panelRight}>{right}</Text></View>;
}

function SettingsScreen({ save, onBack, onToggle, onReset }) {
  const [confirm, setConfirm] = useState(false);
  return (
    <View style={styles.panelRoot}><StatusBar hidden /><SafeAreaView style={styles.full}>
      <PanelHeader title="Ayarlar" onBack={onBack} right="⚙️" />
      <View style={styles.settingsPad}>
        <View style={styles.settingRow}><View><Text style={styles.settingTitle}>Müzik</Text><Text style={styles.settingSub}>Arka plan müziği ayarı</Text></View><Switch value={save.music} onValueChange={v => onToggle('music', v)} /></View>
        <View style={styles.settingRow}><View><Text style={styles.settingTitle}>Efektler</Text><Text style={styles.settingSub}>Oyun sesleri ve geri bildirim</Text></View><Switch value={save.effects} onValueChange={v => onToggle('effects', v)} /></View>
        <View style={styles.parentBox}><Text style={styles.parentTitle}>👨‍👩‍👧 Ebeveyn Alanı</Text><Text style={styles.parentText}>Oyun 7 yaş için kısa, sakin turlara göre tasarlandı. Reklam ve satın alma bağlantısı yoktur.</Text></View>
        <TouchableOpacity onPress={() => setConfirm(true)} style={styles.resetButton}><Text style={styles.resetText}>İlerlemeyi Sıfırla</Text></TouchableOpacity>
      </View>
      <Modal visible={confirm} transparent animationType="fade"><View style={styles.modalShade}><View style={styles.resultCard}><Text style={styles.resultTitle}>İlerleme Silinsin mi?</Text><Text style={styles.resultText}>Yıldızlar, coinler ve alınan eşyalar başlangıç durumuna döner.</Text><TouchableOpacity onPress={() => { onReset(); setConfirm(false); }} style={styles.dangerButton}><Text style={styles.primaryButtonText}>Evet, Sıfırla</Text></TouchableOpacity><TouchableOpacity onPress={() => setConfirm(false)} style={styles.secondaryButton}><Text style={styles.secondaryButtonText}>Vazgeç</Text></TouchableOpacity></View></View></Modal>
    </SafeAreaView></View>
  );
}

export default function App() {
  const [screen, setScreen] = useState('home');
  const [save, setSave] = useState(INITIAL_SAVE);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try { const raw = await AsyncStorage.getItem(SAVE_KEY); if (raw) setSave({ ...INITIAL_SAVE, ...JSON.parse(raw), best: { ...INITIAL_SAVE.best, ...(JSON.parse(raw).best || {}) } }); } catch (e) {}
      setLoaded(true);
    })();
  }, []);
  useEffect(() => { if (loaded) AsyncStorage.setItem(SAVE_KEY, JSON.stringify(save)).catch(() => {}); }, [save, loaded]);

  const completeLevel = (key, rating, reward) => {
    setSave(prev => {
      const oldBest = prev.best[key] || 0;
      const extraStars = Math.max(0, rating - oldBest);
      return { ...prev, coins: prev.coins + reward, stars: prev.stars + extraStars, best: { ...prev.best, [key]: Math.max(oldBest, rating) } };
    });
    setScreen('map');
  };
  const startGame = key => setScreen(key);
  const buyItem = item => setSave(prev => prev.owned.includes(item.id) || prev.coins < item.price ? prev : { ...prev, coins: prev.coins - item.price, owned: [...prev.owned, item.id] });

  if (!loaded) return <View style={styles.loading}><Text style={styles.loadingText}>⭐ Mino hazırlanıyor...</Text></View>;
  return (
    <View style={styles.full}>
      {screen === 'home' && <HomeScreen save={save} onPlay={() => setScreen('map')} onMiniGames={() => setScreen('minigames')} onTree={() => setScreen('tree')} onCollection={() => setScreen('collection')} onSettings={() => setScreen('settings')} />}
      {screen === 'map' && <MapScreen save={save} onBack={() => setScreen('home')} onStart={startGame} />}
      {screen === 'minigames' && <MiniGamesScreen save={save} onBack={() => setScreen('home')} onStart={startGame} />}
      {screen === 'crystal' && <CrystalGame save={save} onExit={() => setScreen('map')} onComplete={completeLevel} />}
      {screen === 'memory' && <MemoryGame save={save} onExit={() => setScreen('map')} onComplete={completeLevel} />}
      {screen === 'math' && <MathGame save={save} onExit={() => setScreen('map')} onComplete={completeLevel} />}
      {screen === 'tree' && <TreeHouseScreen save={save} onBack={() => setScreen('home')} onBuy={buyItem} />}
      {screen === 'collection' && <CollectionScreen save={save} onBack={() => setScreen('home')} />}
      {screen === 'settings' && <SettingsScreen save={save} onBack={() => setScreen('home')} onToggle={(k,v) => setSave(p => ({...p,[k]:v}))} onReset={() => setSave(INITIAL_SAVE)} />}
    </View>
  );
}

const styles = StyleSheet.create({
  full: { flex: 1 }, hotspot: { position: 'absolute', backgroundColor: 'transparent' }, loading: { flex:1, alignItems:'center', justifyContent:'center', backgroundColor:'#163C2B' }, loadingText:{ color:'#FFF5D5', fontSize:22, fontWeight:'900' },
  resourceOverlay:{ position:'absolute', top:10, right:10, flexDirection:'row', gap:8, zIndex:5 }, resourcePill:{ backgroundColor:'rgba(19,46,67,.88)', borderRadius:18, paddingHorizontal:10, paddingVertical:7, borderWidth:1, borderColor:'rgba(255,255,255,.3)' }, resourceText:{ color:'white', fontWeight:'900', fontSize:14 },
  mapChoice:{ position:'absolute', left:'16%', right:'8%', bottom:'3.2%', backgroundColor:'rgba(255,241,200,.96)', borderRadius:20, borderWidth:3, borderColor:'#8B5A24', padding:10 }, mapChoiceTitle:{ fontSize:17, fontWeight:'900', color:'#4A2A1E' }, mapChoiceSub:{ fontSize:12, fontWeight:'700', color:'#5F4A35', marginTop:2 }, mapBest:{ fontSize:14, marginTop:4, fontWeight:'800', color:'#4A2A1E' }, mapStartButton:{ position:'absolute', right:8, bottom:8, backgroundColor:'#49B937', borderRadius:16, paddingHorizontal:17, paddingVertical:9, borderWidth:2, borderColor:'#267C22' }, mapStartText:{ color:'white', fontWeight:'900', fontSize:17 },
  gameRoot:{ flex:1, backgroundColor:'#173B2B' }, hudRow:{ flexDirection:'row', alignItems:'center', gap:10, paddingHorizontal:14, paddingTop:8 }, roundButton:{ width:48, height:48, borderRadius:24, backgroundColor:'#6A4324', alignItems:'center', justifyContent:'center', borderWidth:2, borderColor:'rgba(255,255,255,.4)' }, roundButtonText:{ color:'white', fontSize:40, fontWeight:'800', marginTop:-5 }, hudPill:{ backgroundColor:'#16314A', borderRadius:22, paddingHorizontal:15, paddingVertical:10, borderWidth:2, borderColor:'rgba(255,255,255,.22)' }, hudText:{ color:'white', fontSize:17, fontWeight:'800' },
  missionBox:{ margin:14, marginBottom:8, padding:14, borderRadius:24, backgroundColor:'#FFF4D7', borderWidth:3, borderColor:'#9A6A2B' }, missionTitle:{ fontSize:25, fontWeight:'900', color:'#4A2A1E' }, missionText:{ fontSize:15, fontWeight:'700', color:'#5B4A3A', marginTop:3 }, gameArea:{ flex:1, marginHorizontal:16, borderRadius:24, backgroundColor:'#2B6A45', overflow:'hidden', borderWidth:3, borderColor:'#4C8D5F' }, gameStats:{ flexDirection:'row', justifyContent:'space-around', backgroundColor:'rgba(0,0,0,.18)', padding:12 }, statText:{ color:'white', fontSize:20, fontWeight:'900' },
  crystal:{ position:'absolute', width:86, height:86, borderRadius:43, alignItems:'center', justifyContent:'center', backgroundColor:'rgba(99,210,255,.35)', borderWidth:3, borderColor:'white', elevation:12 }, crystalEmoji:{ fontSize:52 }, sparkle:{ position:'absolute', top:-8, right:-5, fontSize:25 }, decoy:{ position:'absolute', width:72, height:72, alignItems:'center', justifyContent:'center' }, decoyEmoji:{ fontSize:48 }, tipBoxStatic:{ margin:14, marginTop:8, backgroundColor:'#183326', padding:12, borderRadius:18, borderWidth:2, borderColor:'rgba(255,255,255,.22)' }, tipText:{ color:'white', textAlign:'center', fontSize:15, fontWeight:'800' },
  modalShade:{ flex:1, backgroundColor:'rgba(0,0,0,.68)', alignItems:'center', justifyContent:'center', padding:24 }, resultCard:{ width:'100%', maxWidth:420, backgroundColor:'#FFF1C8', borderRadius:30, padding:24, alignItems:'center', borderWidth:4, borderColor:'#7F5524' }, resultTitle:{ fontSize:30, fontWeight:'900', color:'#4A2A1E', textAlign:'center' }, resultStars:{ fontSize:40, marginVertical:12 }, resultText:{ fontSize:16, color:'#5B4A3A', textAlign:'center', fontWeight:'700', lineHeight:23 }, primaryButton:{ marginTop:18, width:'100%', backgroundColor:'#49B937', borderRadius:22, paddingVertical:14, alignItems:'center', borderWidth:3, borderColor:'#277D23' }, primaryButtonText:{ color:'white', fontSize:20, fontWeight:'900' }, secondaryButton:{ marginTop:10, paddingVertical:10, paddingHorizontal:24 }, secondaryButtonText:{ color:'#6A4A31', fontWeight:'800', fontSize:16 }, dangerButton:{ marginTop:18, width:'100%', backgroundColor:'#C74736', borderRadius:22, paddingVertical:14, alignItems:'center', borderWidth:3, borderColor:'#8D2D23' },
  memoryGrid:{ flexDirection:'row', flexWrap:'wrap', justifyContent:'center', gap:8, padding:14, paddingTop:20 }, memoryCard:{ width:'28%', aspectRatio:0.82, borderRadius:16, backgroundColor:'#F1D38E', borderWidth:3, borderColor:'#8B5A24', alignItems:'center', justifyContent:'center' }, memoryMatched:{ backgroundColor:'#BFE5A9', borderColor:'#4C8D42' }, memoryText:{ fontSize:34 },
  mathWrap:{ flex:1, padding:20, alignItems:'center' }, mathProgress:{ color:'#EAF5E8', fontWeight:'800', fontSize:16 }, mathQuestion:{ width:'100%', backgroundColor:'#FFF1C8', borderRadius:24, paddingVertical:30, marginTop:18, alignItems:'center', borderWidth:3, borderColor:'#8B5A24' }, mathQuestionText:{ fontSize:46, fontWeight:'900', color:'#4A2A1E' }, answerRow:{ flexDirection:'row', gap:10, marginTop:24 }, answerButton:{ width:82, height:72, borderRadius:20, backgroundColor:'#49B937', alignItems:'center', justifyContent:'center', borderWidth:3, borderColor:'#277D23' }, answerText:{ color:'white', fontSize:30, fontWeight:'900' }, feedbackText:{ color:'#FFF1C8', fontWeight:'900', fontSize:18, marginTop:18, textAlign:'center' },
  miniRoot:{ flex:1, backgroundColor:'#163C2B', paddingHorizontal:16 }, miniHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingTop:10 }, miniTitle:{ color:'#FFF5D5', fontSize:28, fontWeight:'900' }, miniSubtitle:{ color:'#DFF1D8', fontSize:16, textAlign:'center', marginVertical:20, fontWeight:'700' }, gameCard:{ flexDirection:'row', alignItems:'center', gap:12, backgroundColor:'#FFF0C7', borderRadius:24, padding:15, marginBottom:14, borderWidth:3, borderColor:'#936126' }, gameCardIcon:{ fontSize:40 }, gameCardTitle:{ fontSize:19, fontWeight:'900', color:'#4A2A1E' }, gameCardSub:{ fontSize:12, color:'#6B5A45', fontWeight:'700', marginTop:2 }, gameCardState:{ fontSize:14, fontWeight:'900', color:'#2F7D2D' }, bestSmall:{ fontSize:12, marginTop:5, fontWeight:'800', color:'#805A20' },
  panelRoot:{ flex:1, backgroundColor:'#163C2B' }, panelHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal:14, paddingTop:10 }, panelTitle:{ color:'#FFF5D5', fontSize:27, fontWeight:'900' }, panelRight:{ color:'#FFF5D5', fontWeight:'900', fontSize:16, minWidth:60, textAlign:'right' }, scrollPad:{ padding:16, paddingBottom:40 }, treePreview:{ backgroundColor:'#FFF0C7', borderRadius:28, padding:18, alignItems:'center', borderWidth:3, borderColor:'#936126' }, treeEmoji:{ fontSize:70 }, treeTitle:{ fontSize:23, fontWeight:'900', color:'#4A2A1E' }, treeSub:{ color:'#6B5A45', fontWeight:'700', marginTop:4 }, ownedRow:{ flexDirection:'row', flexWrap:'wrap', justifyContent:'center', marginTop:10 }, ownedIcon:{ fontSize:28, margin:4 }, sectionTitle:{ color:'#FFF5D5', fontSize:22, fontWeight:'900', marginTop:20, marginBottom:10 }, shopGrid:{ flexDirection:'row', flexWrap:'wrap', gap:10 }, shopCard:{ width:'48%', backgroundColor:'#FFF0C7', borderRadius:20, padding:13, alignItems:'center', borderWidth:2, borderColor:'#936126' }, shopIcon:{ fontSize:42 }, shopName:{ fontWeight:'900', color:'#4A2A1E', textAlign:'center', marginVertical:6 }, buyButton:{ backgroundColor:'#49B937', borderRadius:14, paddingHorizontal:12, paddingVertical:8 }, buyDisabled:{ backgroundColor:'#999' }, buyText:{ color:'white', fontWeight:'900' },
  collectionHero:{ fontSize:62, textAlign:'center' }, collectionTitle:{ color:'#FFF5D5', fontSize:25, fontWeight:'900', textAlign:'center', marginBottom:16 }, badgeCard:{ flexDirection:'row', alignItems:'center', backgroundColor:'#FFF0C7', borderRadius:20, padding:14, marginBottom:10, borderWidth:2, borderColor:'#936126' }, badgeIcon:{ fontSize:36, marginRight:12 }, badgeName:{ fontSize:17, fontWeight:'900', color:'#4A2A1E' }, badgeSub:{ fontSize:12, color:'#6B5A45', fontWeight:'700' }, badgeStars:{ fontSize:15 }, collectionGrid:{ flexDirection:'row', flexWrap:'wrap', gap:10 }, collectItem:{ width:'48%', backgroundColor:'#FFF0C7', borderRadius:18, padding:12, alignItems:'center' }, collectLocked:{ opacity:.55 }, collectIcon:{ fontSize:36 }, collectName:{ fontSize:12, fontWeight:'900', color:'#4A2A1E', textAlign:'center', marginTop:4 },
  settingsPad:{ padding:16 }, settingRow:{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', backgroundColor:'#FFF0C7', borderRadius:20, padding:16, marginBottom:12, borderWidth:2, borderColor:'#936126' }, settingTitle:{ fontSize:18, fontWeight:'900', color:'#4A2A1E' }, settingSub:{ fontSize:12, color:'#6B5A45', marginTop:2 }, parentBox:{ backgroundColor:'#D9ECD1', borderRadius:20, padding:16, marginTop:8 }, parentTitle:{ fontSize:18, fontWeight:'900', color:'#29452D' }, parentText:{ fontSize:13, fontWeight:'700', color:'#405C44', lineHeight:20, marginTop:5 }, resetButton:{ marginTop:18, backgroundColor:'#8F3D32', borderRadius:18, padding:14, alignItems:'center' }, resetText:{ color:'white', fontWeight:'900', fontSize:16 },
});
